HARD — The Hummingbird Rush (PWA package)

HOW TO PUBLISH:
1. Upload the CONTENTS of this folder to a static HTTPS host (for example Netlify Drop or GitHub Pages).
2. Open the published HTTPS website in Chrome on Android.
3. Tap Chrome menu (⋮) and choose "Install app" or "Add to Home screen".
4. Confirm. The icon will appear as HARD.

IMPORTANT:
- Do not open index.html as a local file if you want installation; PWA installation requires HTTPS (localhost is the development exception).
- Keep index.html, manifest.webmanifest, sw.js, and the icons folder together.
- The service worker caches the game files for offline launch after the first successful visit.
